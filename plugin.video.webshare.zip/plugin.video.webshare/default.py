import xbmcplugin, xbmcgui, xbmcaddon, xbmc
import sys, os, json, requests, urllib.parse

addon = xbmcaddon.Addon()
addon_id = addon.getAddonInfo('id')
addon_data_path = xbmc.translatePath(f"special://profile/addon_data/{addon_id}")
token_file = os.path.join(addon_data_path, "token.json")
history_file = os.path.join(addon_data_path, "search_history.json")
progress_file = os.path.join(addon_data_path, "progress.json")

USERNAME = addon.getSetting('username')
PASSWORD = addon.getSetting('password')
HANDLE = int(sys.argv[1])
BASE_API = "https://webshare.cz/api"

def save_token(token):
    os.makedirs(addon_data_path, exist_ok=True)
    with open(token_file, "w") as f:
        json.dump({"token": token}, f)

def load_token():
    if os.path.exists(token_file):
        with open(token_file) as f:
            return json.load(f).get("token")
    return None

def get_new_token():
    r = requests.post(f"{BASE_API}/login/", json={"username": USERNAME, "password": PASSWORD})
    if r.status_code == 200:
        token = r.json().get("token")
        save_token(token)
        return token
    xbmcgui.Dialog().ok("Přihlášení selhalo", "Zkontroluj přihlašovací údaje.")
    return None

def api_get(endpoint, token):
    headers = {"Authorization": f"Bearer {token}"}
    r = requests.get(f"{BASE_API}/{endpoint}", headers=headers)
    if r.status_code == 401:
        token = get_new_token()
        if token:
            return api_get(endpoint, token)
    elif r.status_code == 200:
        return r.json()
    xbmcgui.Dialog().notification("Webshare", f"API chyba: {r.status_code}", xbmcgui.NOTIFICATION_ERROR)
    return None

def add_to_history(term):
    try:
        history = json.load(open(history_file))
    except:
        history = []
    if term not in history:
        history.insert(0, term)
        history = history[:10]
        json.dump(history, open(history_file, "w"))

def show_history():
    try:
        history = json.load(open(history_file))
    except:
        history = []
    if not history:
        xbmcgui.Dialog().ok("Historie", "Historie je prázdná.")
        return
    index = xbmcgui.Dialog().select("Historie hledání", history)
    if index >= 0:
        query = history[index]
        show_files(f"file/list/?search={query}&limit=50")

def save_progress(name, url):
    try:
        data = json.load(open(progress_file))
    except:
        data = {}
    data[name] = url
    json.dump(data, open(progress_file, "w"))

def show_progress():
    try:
        data = json.load(open(progress_file))
    except:
        xbmcgui.Dialog().ok("Rozkoukané", "Žádná rozkoukaná videa")
        return
    for name, url in data.items():
        li = xbmcgui.ListItem(label=name)
        li.setInfo("video", {"title": name})
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(HANDLE, url, li, False)
    xbmcplugin.endOfDirectory(HANDLE)

def show_files(endpoint="file/list/?limit=20"):
    token = load_token() or get_new_token()
    if not token:
        return
    data = api_get(endpoint, token)
    if not data or "data" not in data:
        return
    files = sorted(data["data"]["files"], key=lambda x: x.get("uploaded", ""), reverse=True)
    for file in files:
        name = file["name"]
        stream_link = file.get("stream_link")
        if stream_link:
            li = xbmcgui.ListItem(label=name)
            li.setInfo("video", {
                "title": name,
                "plot": f"Nahráno: {file.get('uploaded', '')}",
                "size": round(int(file['size']) / (1024**2), 2)
            })
            li.setArt({'icon': 'icon.png', 'thumb': 'icon.png'})
            li.setProperty("IsPlayable", "true")
            xbmcplugin.addDirectoryItem(HANDLE, stream_link, li, False)
            save_progress(name, stream_link)
    xbmcplugin.endOfDirectory(HANDLE)

def search_files():
    query = xbmcgui.Dialog().input("Zadej hledaný výraz")
    if not query:
        return
    add_to_history(query)
    show_files(f"file/list/?search={query}&limit=50")

def main_menu():
    items = [
        ("🗂 Moje soubory", "list"),
        ("🔍 Hledat", "search"),
        ("🕘 Historie hledání", "history"),
        ("🎞 Rozkoukaná videa", "progress"),
    ]
    for label, mode in items:
        url = f"{sys.argv[0]}?mode={mode}"
        li = xbmcgui.ListItem(label=label)
        xbmcplugin.addDirectoryItem(HANDLE, url, li, True)
    xbmcplugin.endOfDirectory(HANDLE)

def router():
    params = dict(urllib.parse.parse_qs(sys.argv[2][1:]))
    mode = params.get("mode", ["main"])[0]
    if mode == "list":
        show_files()
    elif mode == "search":
        search_files()
    elif mode == "history":
        show_history()
    elif mode == "progress":
        show_progress()
    else:
        main_menu()

if __name__ == "__main__":
    router()
